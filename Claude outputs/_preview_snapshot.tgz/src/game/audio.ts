export class SoundManager {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;
  private splashBuffer: AudioBuffer | null = null;
  private sources = new Map<AudioScheduledSourceNode, AudioNode[]>();
  private idleTimer: ReturnType<typeof setTimeout> | null = null;
  private resumePending: Promise<void> | null = null;
  private listening = false;

  constructor() {
    try {
      this.muted = localStorage.getItem('pixel_pool_muted') === 'true';
    } catch {
      // Storage can be unavailable in private browsing.
    }
  }

  private initCtx() {
    if (this.idleTimer !== null) clearTimeout(this.idleTimer);
    this.idleTimer = null;
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      this.ctx = new AudioContextClass({ latencyHint: 'interactive' });
    }
    if (!this.listening) {
      document.addEventListener('visibilitychange', this.handleVisibilityChange);
      window.addEventListener('pagehide', this.handlePageHide);
      this.listening = true;
    }
    if (this.ctx.state === 'suspended' && !this.resumePending) {
      const ctx = this.ctx;
      const resume = ctx.resume();
      this.resumePending = resume;
      void resume.then(() => {
        if (ctx === this.ctx && (this.muted || document.hidden || this.sources.size === 0)) {
          return ctx.suspend();
        }
      }).catch(() => {
        // Browsers can require another user gesture before resuming audio.
      }).finally(() => {
        if (this.resumePending === resume) this.resumePending = null;
      });
    }
  }

  private canPlay(): boolean {
    return !this.muted && typeof document !== 'undefined' && !document.hidden
      && this.sources.size < 24;
  }

  private handleVisibilityChange = () => {
    if (document.hidden) this.suspend();
  };

  private handlePageHide = () => this.suspend();

  private trackSource(source: AudioScheduledSourceNode, ...nodes: AudioNode[]) {
    this.sources.set(source, nodes);
    source.onended = () => {
      source.onended = null;
      source.disconnect();
      nodes.forEach((node) => node.disconnect());
      this.sources.delete(source);
      if (this.sources.size === 0) {
        if (this.idleTimer !== null) clearTimeout(this.idleTimer);
        // A short grace period keeps footsteps responsive while allowing the
        // audio device to sleep when the player is idle.
        this.idleTimer = setTimeout(() => this.suspend(), 1000);
      }
    };
  }

  public suspend() {
    if (this.idleTimer !== null) clearTimeout(this.idleTimer);
    this.idleTimer = null;
    this.sources.forEach((nodes, source) => {
      source.onended = null;
      try { source.stop(); } catch { /* Already stopped. */ }
      source.disconnect();
      nodes.forEach((node) => node.disconnect());
    });
    this.sources.clear();
    if (this.ctx && this.ctx.state !== 'closed') void this.ctx.suspend().catch(() => {});
  }

  public destroy() {
    this.suspend();
    if (this.listening) {
      document.removeEventListener('visibilitychange', this.handleVisibilityChange);
      window.removeEventListener('pagehide', this.handlePageHide);
      this.listening = false;
    }
    const ctx = this.ctx;
    this.ctx = null;
    this.splashBuffer = null;
    this.resumePending = null;
    if (ctx && ctx.state !== 'closed') void ctx.close().catch(() => {});
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    try { localStorage.setItem('pixel_pool_muted', String(muted)); } catch { /* Optional persistence. */ }
    if (muted) this.suspend();
  }

  public toggleMute(): boolean {
    this.setMuted(!this.muted);
    return this.muted;
  }

  // Water splash sound (noise filtered + bubble drop)
  public playSplash() {
    if (!this.canPlay()) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;

      // 1. White noise burst
      if (!this.splashBuffer) {
        const bufferSize = Math.ceil(this.ctx.sampleRate * 0.25);
        this.splashBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = this.splashBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
      }
      const noise = this.ctx.createBufferSource();
      noise.buffer = this.splashBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(900, t);
      filter.frequency.exponentialRampToValueAtTime(150, t + 0.25);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      this.trackSource(noise, filter, gain);
      noise.start(t);
      noise.stop(t + 0.25);

      // 2. Bubbly tone
      const osc = this.ctx.createOscillator();
      const oscGain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(450, t);
      osc.frequency.exponentialRampToValueAtTime(180, t + 0.18);
      oscGain.gain.setValueAtTime(0.2, t);
      oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(oscGain);
      oscGain.connect(this.ctx.destination);
      this.trackSource(osc, oscGain);
      osc.start(t);
      osc.stop(t + 0.2);
    } catch {
      // Audio error catch
    }
  }

  // Soft footstep tap on poolside tiles
  public playFootstep() {
    if (!this.canPlay()) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140, t);
      osc.frequency.exponentialRampToValueAtTime(50, t + 0.05);

      gain.gain.setValueAtTime(0.08, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      this.trackSource(osc, gain);
      osc.start(t);
      osc.stop(t + 0.05);
    } catch {
      // Audio error catch
    }
  }

  // Retro message chime
  public playChatChime() {
    if (!this.canPlay()) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;

      const notes = [587.33, 880]; // D5, A5
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(freq, t + idx * 0.08);

        gain.gain.setValueAtTime(0.12, t + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.08 + 0.12);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        this.trackSource(osc, gain);
        osc.start(t + idx * 0.08);
        osc.stop(t + idx * 0.08 + 0.14);
      });
    } catch {
      // Audio error catch
    }
  }

  // Emote jingle based on action
  public playEmoteSound(action: string) {
    if (!this.canPlay()) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;

      let notes = [523.25, 659.25, 783.99]; // C5, E5, G5
      let type: OscillatorType = 'triangle';

      if (action === 'happy') {
        notes = [523.25, 659.25, 783.99, 1046.5]; // C, E, G, C
        type = 'square';
      } else if (action === 'surprise') {
        notes = [440, 880];
        type = 'sawtooth';
      } else if (action === 'relax') {
        notes = [440, 554.37, 659.25];
        type = 'sine';
      } else if (action === 'jump') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(200, t);
        osc.frequency.exponentialRampToValueAtTime(600, t + 0.15);
        gain.gain.setValueAtTime(0.15, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        this.trackSource(osc, gain);
        osc.start(t);
        osc.stop(t + 0.16);
        return;
      }

      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, t + idx * 0.07);

        gain.gain.setValueAtTime(0.1, t + idx * 0.07);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.07 + 0.15);

        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        this.trackSource(osc, gain);
        osc.start(t + idx * 0.07);
        osc.stop(t + idx * 0.07 + 0.16);
      });
    } catch {
      // Audio error catch
    }
  }

  // Short blip when navigating menus/boxes
  public playCursor() {
    if (!this.canPlay()) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(880, t);
      gain.gain.setValueAtTime(0.04, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      this.trackSource(osc, gain);
      osc.start(t);
      osc.stop(t + 0.04);
    } catch {}
  }

  // Low buzz when action is rejected / invalid
  public playBuzzer() {
    if (!this.canPlay()) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(120, t);
      gain.gain.setValueAtTime(0.08, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      this.trackSource(osc, gain);
      osc.start(t);
      osc.stop(t + 0.15);
    } catch {}
  }

  // Affirmative chime for travel / scene select
  public playSelect() {
    if (!this.canPlay()) return;
    try {
      this.initCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, t); // C5
      osc.frequency.setValueAtTime(659.25, t + 0.08); // E5
      gain.gain.setValueAtTime(0.1, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      this.trackSource(osc, gain);
      osc.start(t);
      osc.stop(t + 0.22);
    } catch {}
  }
}

export const sound = new SoundManager();
